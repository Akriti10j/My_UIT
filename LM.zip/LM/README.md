# Smart Library Management System (Django & SQLite3)

A production-ready Final Year Project designed to automate library operations, student enrollments, book checkouts, overdue calculations, and administrative analytics.

---

## 🚀 Key Features

### 👤 Administrator Features
- **Analytics Dashboard**: Real-time metrics counters for inventory, checkouts, and fine collections.
- **Vetting Queue**: Vetting panel to approve student registration requests.
- **Inventory CRUD**: Catalog books, categories, and authors.
- **QR Code Labeling**: Automatic QR code image generation for cataloged books.
- **Circulation Management**: Process book issues and return checkouts.
- **Fines Collection Ledger**: Record overdue charges (₹5/day after 15 days) and settle payments.
- **Reports Export Engine**: Single-click PDF and Excel sheet summaries for audits.

### 🎓 Student Features
- **Portal Desk**: Real-time dashboard with active checkouts, notifications, and balance metrics.
- **Dynamic Search Catalog**: Filter inventory by titles, authors, categories, or ISBNs.
- **Checkouts & Reservations**: Request available books and reserve out-of-stock items.
- **Issue Receipts**: Download official PDF issue receipts.
- **Profile Updates**: Manage contact numbers and academic semesters.

---

## 🛠️ Technology Stack
- **Backend**: Django 5.x, Python 3.12+
- **Database**: SQLite3
- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript, Django Templates
- **REST Services**: Django REST Framework (DRF)
- **Utilities**: ReportLab (PDFs), OpenPyXL (Excel), QRCode, Pillow (Images)

---

## 📂 Project Structure
```
smart_library/
├── manage.py
├── requirements.txt
├── smart_library/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── library/
│   ├── admin.py
│   ├── forms.py
│   ├── models.py
│   ├── serializers.py
│   ├── urls.py
│   ├── utils.py
│   ├── views.py
│   ├── static/
│   │   ├── css/
│   │   │   ├── style.css
│   │   │   └── dark-mode.css
│   │   └── js/
│   │       └── main.js
│   └── templates/
│       ├── base.html
│       ├── public/
│       │   ├── home.html, about.html, contact.html, login.html, register.html
│       ├── admin_dashboard/
│       │   ├── dashboard.html, book_list.html, category_list.html, etc.
│       └── student_dashboard/
│           ├── dashboard.html, profile.html, book_search.html, etc.
└── documentation/
    ├── synopsis.md
    ├── srs_documentation.md
    ├── schema.md
    ├── er_diagram.md
    ├── use_case_diagram.md
    ├── installation_guide.md
    ├── deployment_guide.md
    └── viva_questions.md
```

---

## ⚙️ Quick Installation

1. **Clone or Download** the project repository.
2. **Create virtual environment** and activate it:
   ```bash
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # macOS/Linux:
   source venv/bin/activate
   ```
3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
4. **Run migrations**:
   ```bash
   python manage.py makemigrations library
   python manage.py migrate
   ```
5. **Create Administrator Account**:
   ```bash
   python manage.py createsuperuser
   ```
6. **Launch local web server**:
   ```bash
   python manage.py runserver
   ```
   Open **[http://127.0.0.1:8000/](http://127.0.0.1:8000/)** in your web browser.

---

## 📚 Technical Documentation & Guides
For deeper architectural analysis:
- **Project Abstract & Goals**: See [synopsis.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/synopsis.md)
- **Requirements Specification**: See [srs_documentation.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/srs_documentation.md)
- **Database SQL Fields**: See [schema.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/schema.md)
- **ER Relationships Diagram**: See [er_diagram.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/er_diagram.md)
- **Workflows Use Case Diagram**: See [use_case_diagram.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/use_case_diagram.md)
- **Developer Installation Guide**: See [installation_guide.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/installation_guide.md)
- **Linux Deployment Guide**: See [deployment_guide.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/deployment_guide.md)
- **Viva-Voce Q&A Prep Sheet**: See [viva_questions.md](file:///c:/Users/Aman%20Mishra/OneDrive/Desktop/LM/documentation/viva_questions.md)
