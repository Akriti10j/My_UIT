# Entity Relationship (ER) Diagram

The following Mermaid diagram shows the relational schema of the database including foreign keys, tables, and relationships.

```mermaid
erDiagram
    STUDENT {
        int id PK
        string username UNIQUE
        string email
        string roll_number UNIQUE
        string phone
        string course
        string branch
        string semester
        string profile_picture
        boolean is_approved
        boolean is_staff
        datetime created_at
    }

    CATEGORY {
        int id PK
        string category_name UNIQUE
        string description
    }

    AUTHOR {
        int id PK
        string author_name
        string biography
    }

    BOOK {
        int id PK
        string title
        string isbn UNIQUE
        int category_id FK
        int author_id FK
        string publisher
        int publication_year
        int quantity
        int available_quantity
        string cover_image
        string qr_code
        text description
        datetime created_at
    }

    ISSUE_BOOK {
        int id PK
        int student_id FK
        int book_id FK
        date issue_date
        date due_date
        date return_date
        string status
        decimal fine_amount
    }

    FINE {
        int id PK
        int student_id FK
        int issue_record_id FK
        decimal amount
        boolean paid_status
    }

    BOOK_RESERVATION {
        int id PK
        int student_id FK
        int book_id FK
        datetime reservation_date
        string status
    }

    ACTIVITY_LOG {
        int id PK
        int user_id FK
        string action
        text details
        datetime timestamp
    }

    STUDENT ||--o{ ISSUE_BOOK : requests_or_borrowed
    STUDENT ||--o{ FINE : incurs
    STUDENT ||--o{ BOOK_RESERVATION : places
    STUDENT ||--o{ ACTIVITY_LOG : triggers

    CATEGORY ||--o{ BOOK : contains
    AUTHOR ||--o{ BOOK : writes

    BOOK ||--o{ ISSUE_BOOK : transacted_in
    BOOK ||--o{ BOOK_RESERVATION : holds

    ISSUE_BOOK ||--o| FINE : associated_with
```
