# Installation Guide - Smart Library Management System

This document outlines instructions for setting up the development environment and launching the Smart Library Management System.

## Prerequisites
Ensure the following tools are installed on your workstation:
- **Python**: Version 3.12 or above.
- **Pip**: Python Package Installer.
- **Git**: (Optional) For cloning code repositories.

---

## Step 1: Create and Activate Virtual Environment (Recommended)
Open a terminal in the project directory and create a virtual environment to keep dependencies isolated:

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

---

## Step 2: Install Required Dependencies
Install the required packages list specified in `requirements.txt`:

```bash
pip install -r requirements.txt
```

---

## Step 3: Run Database Migrations
Create and configure the local SQLite database schema based on Django models:

```bash
# Generate migration files
python manage.py makemigrations library

# Apply migrations to SQLite database
python manage.py migrate
```

---

## Step 4: Create Superuser Account (Administrator)
Create the primary admin account to manage books, categories, and student approvals:

```bash
python manage.py createsuperuser
```
Follow the command line prompts:
1. Enter username (e.g. `admin`).
2. Enter email address (e.g. `admin@library.com`).
3. Enter password (must be at least 8 characters long).

---

## Step 5: Start Development Web Server
Run the local Django development server:

```bash
python manage.py runserver
```

You can now access the system from your web browser at:
**[http://127.0.0.1:8000/](http://127.0.0.1:8000/)**

- To access the admin panel, login with your superuser credentials.
- To access student features, register a student account, then log in using the admin account to approve the registration first.
