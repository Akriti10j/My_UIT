# Database Schema - Smart Library Management System

This document outlines the database schema configured for SQLite3.

---

## 1. Table: `library_student` (Custom User Model)
Inherits from Django `auth_user` table structure.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `username` | VARCHAR(150) | UNIQUE, NOT NULL | Account Username |
| `password` | VARCHAR(128) | NOT NULL | Hashed password |
| `email` | VARCHAR(254) | NOT NULL | Email address |
| `first_name` | VARCHAR(150) | NOT NULL | First Name |
| `last_name` | VARCHAR(150) | NOT NULL | Last Name |
| `roll_number` | VARCHAR(50) | UNIQUE, NOT NULL | Student ID / Roll Number |
| `phone` | VARCHAR(15) | NOT NULL | Phone number |
| `course` | VARCHAR(100) | NOT NULL | E.g., B.Tech, MCA, BSC |
| `branch` | VARCHAR(100) | NOT NULL | E.g., Computer Science, Electrical |
| `semester` | VARCHAR(20) | NOT NULL | Academic Semester |
| `profile_picture`| VARCHAR(100) | NULLABLE | Upload path to media directory |
| `is_approved` | BOOLEAN | DEFAULT FALSE | Status for admin approval |
| `is_staff` | BOOLEAN | DEFAULT FALSE | Django staff indicator (Admin role) |
| `is_superuser` | BOOLEAN | DEFAULT FALSE | Django admin indicator |
| `created_at` | DATETIME | NOT NULL, AUTO_NOW_ADD | Date/time registered |

---

## 2. Table: `library_category`
Stores book categories.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `category_name` | VARCHAR(100) | UNIQUE, NOT NULL | Category name |
| `description` | TEXT | NULLABLE | Details about category |

---

## 3. Table: `library_author`
Stores book authors.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `author_name` | VARCHAR(150) | NOT NULL | Author's name |
| `biography` | TEXT | NULLABLE | Author's short bio |

---

## 4. Table: `library_book`
Stores book inventory and metadata.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `title` | VARCHAR(200) | NOT NULL | Book title |
| `isbn` | VARCHAR(20) | UNIQUE, NOT NULL | ISBN code |
| `category_id` | INTEGER | FOREIGN KEY (`library_category`.`id`) | Book category |
| `author_id` | INTEGER | FOREIGN KEY (`library_author`.`id`) | Book author |
| `publisher` | VARCHAR(150) | NOT NULL | Publisher name |
| `publication_year`| INTEGER | NOT NULL | Year of publication |
| `quantity` | INTEGER | NOT NULL, DEFAULT 0 | Total copies in library |
| `available_quantity`| INTEGER | NOT NULL, DEFAULT 0 | Currently available copies |
| `cover_image` | VARCHAR(100) | NULLABLE | Book cover image path |
| `qr_code` | VARCHAR(100) | NULLABLE | QR code path |
| `description` | TEXT | NULLABLE | Summary of the book |
| `created_at` | DATETIME | NOT NULL, AUTO_NOW_ADD | Record creation time |

---

## 5. Table: `library_issuebook`
Tracks books issued or requested by students.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `student_id` | INTEGER | FOREIGN KEY (`library_student`.`id`) | Student who requested/issued |
| `book_id` | INTEGER | FOREIGN KEY (`library_book`.`id`) | Book transaction reference |
| `issue_date` | DATE | NULLABLE | Date book was approved/issued |
| `due_date` | DATE | NULLABLE | Date book must be returned |
| `return_date` | DATE | NULLABLE | Actual date returned |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'PENDING' | Status: PENDING, ISSUED, RETURNED, REJECTED |
| `fine_amount` | DECIMAL(8, 2) | DEFAULT 0.00 | Total calculated fine |

---

## 6. Table: `library_fine`
Tracks fines charged and paid.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `student_id` | INTEGER | FOREIGN KEY (`library_student`.`id`) | Student who owes fine |
| `issue_record_id`| INTEGER | FOREIGN KEY (`library_issuebook`.`id`) | Related issue record |
| `amount` | DECIMAL(8, 2) | NOT NULL, DEFAULT 0.00 | Fine balance amount |
| `paid_status` | BOOLEAN | DEFAULT FALSE | Payment status |

---

## 7. Table: `library_bookreservation`
Tracks reservations when availability is zero.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `student_id` | INTEGER | FOREIGN KEY (`library_student`.`id`) | Student reserving |
| `book_id` | INTEGER | FOREIGN KEY (`library_book`.`id`) | Book reserved |
| `reservation_date`| DATETIME | NOT NULL, AUTO_NOW_ADD | Date of reservation |
| `status` | VARCHAR(20) | NOT NULL, DEFAULT 'PENDING' | PENDING, COMPLETED, EXPIRED |

---

## 8. Table: `library_activitylog`
Audits system activities.

| Field Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| `user_id` | INTEGER | FOREIGN KEY (`library_student`.`id`) NULLABLE | Acting user |
| `action` | VARCHAR(100) | NOT NULL | Action name (e.g. LOGIN, ADD_BOOK) |
| `details` | TEXT | NOT NULL | Detailed action log |
| `timestamp` | DATETIME | NOT NULL, AUTO_NOW_ADD | Trigger time |
