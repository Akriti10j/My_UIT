# Software Requirements Specification (SRS)
## Smart Library Management System

## 1. Introduction
This Software Requirements Specification (SRS) document details the functional and non-functional requirements for the **Smart Library Management System**. 

## 2. Overall Description
The system is a responsive, web-based portal designed to handle school or college library management workflows. It reduces physical paperwork, prevents book hoarding, provides transparency to students, and allows administrators to oversee all activities from a single console.

### 2.1 Product Perspective
The system is built as a standalone web application using Django. It features a local relational SQLite database and exposes REST APIs for prospective mobile or external client access.

### 2.2 Product Functions
- Role-based user authentication.
- Admin verification/approval of new student accounts.
- Book catalog management (Categories, Authors, Books, stock availability).
- Issuing and returning workflow with automated fine calculations.
- QR Code generation containing book metadata.
- Email notifications/reminders for due dates.
- Book reservations when books are out of stock.
- Simple, category-based book recommendations.
- Interactive, responsive UI with light/dark theme switching.
- Data export features (PDF & Excel format).
- System auditing via activity logs.

### 2.3 User Classes and Characteristics
1. **Administrator (Librarian/Staff)**: Full CRUD permissions, approval authority, collection monitoring, manual returning, fine collection, and report generation.
2. **Student**: Register, manage profile, search catalog, request book issue, reserve out-of-stock items, view active issues, fine details, and download issue receipts.

## 3. Specific Requirements

### 3.1 Functional Requirements

#### 3.1.1 User Authentication & Registration (RBAC)
- **REQ-1**: Students can register with details: username, email, first name, last name, roll number, phone, course, branch, semester, and profile picture.
- **REQ-2**: Newly registered student accounts must remain inactive and cannot log in until an Admin marks them as approved.
- **REQ-3**: Secure password hashing must be enforced.

#### 3.1.2 Catalog Management
- **REQ-4**: Admins can add, update, and delete categories and authors.
- **REQ-5**: Admins can add, update, and delete books. Adding a book automatically creates a unique QR code with the book details.
- **REQ-6**: Book quantity and available quantity are tracked. If availability is 0, students cannot request to issue it.

#### 3.1.3 Issuing & Returns
- **REQ-7**: A student can request to issue a book. If availability > 0 and the student currently has less than 3 issued books, the request can be submitted.
- **REQ-8**: The book is only marked as "issued" when an Admin approves the request. Upon approval, the book's available quantity decreases by 1.
- **REQ-9**: The standard issue duration is 15 days.
- **REQ-10**: When a book is returned, the Admin marks the return date. The book's available quantity increases by 1.
- **REQ-11**: Fine calculations occur automatically: if returned after the due date, a fine of ₹5 per day is calculated and charged to the student's account.

#### 3.1.4 Reservations & Recommendations
- **REQ-12**: If a book is unavailable (available quantity = 0), a student can submit a Reservation request.
- **REQ-13**: The system displays book recommendations on the student's dashboard based on books in categories they have borrowed previously, or popular books.

#### 3.1.5 Reporting & Exports
- **REQ-14**: Admins can download Book, Student, Issue, Return, and Fine reports.
- **REQ-15**: Reports can be downloaded as formatted PDFs (using ReportLab) or Excel sheets (using OpenPyXL).
- **REQ-16**: Students can download their individual issue receipt as a PDF.

#### 3.1.6 REST APIs
- **REQ-17**: REST endpoints must be available for login, register, books catalog, student details, issue transactions, returns, and fines.

### 3.2 Non-Functional Requirements
- **Security**: Prevent SQL injection via Django's ORM, enable CSRF protection, and validate inputs.
- **Usability**: Mobile-friendly, responsive layout using Bootstrap 5, incorporating DataTables with sorting and pagination, and dark mode toggling.
- **Performance**: Rapid search and pagination handling, processing database queries efficiently.
- **Reliability**: Secure file uploads (cover photos and QR codes) and transactional database integrity (using Django `atomic` transactions where appropriate).
