# Viva Questions and Answers: Smart Library Management System

This document contains a compilation of common questions asked during project viva-voce examinations and their detailed answers related to this system.

---

## 1. Project Overview & Architecture

### Q1: What is the main objective of this project?
**Answer**: The main objective is to automate library processes including book cataloging, user registration with admin vetting, book requests, returns, reservation management, and automatic fine calculation. The goal is to eliminate paper-based record-keeping, prevent book hoarding, and provide a self-service portal for students and analytics for the admin.

### Q2: Explain the software architecture of your application.
**Answer**: The project follows the **Model-View-Template (MVT)** design pattern provided by the Django framework:
- **Model**: Defines the database schema, structures, and business rules (e.g. `Book`, `Student`, `IssueBook`).
- **Template**: The user interface rendered using HTML, CSS, JavaScript, and Bootstrap 5.
- **View**: Contains the core business logic, query calculations, and interacts with Models to fetch data and return it to templates.

### Q3: Why did you choose SQLite as your database?
**Answer**: SQLite was chosen because it is serverless, self-contained, requires zero configuration, and stores data in a single file. It is perfect for development, testing, and small-to-medium institutional deployments. If the system scales, Django makes it simple to swap SQLite for PostgreSQL or MySQL by modifying only the database configuration in `settings.py`.

---

## 2. Technical Implementation & Django Concepts

### Q4: How did you implement user authentication and Role-Based Access Control (RBAC)?
**Answer**: We extended Django’s built-in `AbstractUser` model to create a custom user model `Student`. We distinguished roles by utilizing:
- **Admin**: Users with the `is_staff` or `is_superuser` flags set to `True`.
- **Student**: Standard users who must also have their custom field `is_approved` set to `True` by an Admin before they can log in or request issues.
We protected views using Django's `@login_required` decorators and custom helper tests (e.g., `user_passes_test` for staff checks) to guarantee role-based route protection.

### Q5: How is the automatic QR Code generation implemented?
**Answer**: We override the `save()` method on the `Book` model. When a book is created, we use the `qrcode` library to generate a QR image containing key details (ISBN, Title, Author). The image is converted into a binary buffer, wrapped in a Django `File` object, and saved to the book's `qr_code` field which uploads it to the server's media storage.

### Q6: How does the system calculate fines automatically?
**Answer**: Fines are dynamically updated. We write logic that:
1. Compares the current date (or return date if returned) against the `due_date`.
2. If the current date is past the due date, we calculate the difference in days.
3. The difference is multiplied by ₹5 (defined in the business rules).
4. This calculation runs dynamically when displaying issue history and updates the fine records accordingly.

### Q7: What are Django signals, and did you use them?
**Answer**: Django signals allow decoupled applications to get notified when actions occur elsewhere. In this project, we used database triggers/logic directly in views and model methods (like overriding `save()`) to handle stock reductions/increments when book issue status changes.

---

## 3. Database & System Logic

### Q8: What database constraints prevent students from borrowing too many books or unavailable books?
**Answer**: Before submitting an issue request, the system checks two conditions:
1. `book.available_quantity > 0` (preventing request of out-of-stock items).
2. The student’s count of active issues (status = `'ISSUED'`) is `< 3`.
If these conditions are met, the transaction proceeds; otherwise, Django raises forms validation errors.

### Q9: How is the Book Reservation system different from Book Issuing?
**Answer**: Book issuing requires the book to be in stock and is given to the student immediately. Book reservation is used when a book's `available_quantity` is 0. A student reserves the book, queueing themselves for the book. When a book is returned, the admin sees the queue and can prioritize issuance.

### Q10: How did you generate reports?
**Answer**:
- **Excel reports**: Generated using `openpyxl` by writing database query records row-by-row into a workbook stream.
- **PDF reports**: Created using `reportlab` with customized flowables, tables, and alignment parameters.
Both reports are returned as HTTP attachments, triggering downloads directly in the browser.
