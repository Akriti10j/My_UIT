# Deployment Guide - Smart Library Management System

This document outlines guidelines to configure and deploy the Smart Library Management System to a production Linux server (Ubuntu/Debian) utilizing **Gunicorn**, **Nginx**, and security settings.

---

## 1. Production Settings Configuration (`settings.py`)
Before deployment, configure security tokens and disable debugging:

- **Disable Debugging**:
  `DEBUG = False`
- **Configure Secret Key**: Set a secure cryptographic key via environment variable:
  `SECRET_KEY = os.environ.get('SECRET_KEY', 'your-default-secure-key')`
- **Allowed Hosts**: Define domain names or server IP:
  `ALLOWED_HOSTS = ['yourdomain.com', 'server_ip']`
- **Secure File Directories**: Collect static files into a single location:
  `python manage.py collectstatic`

---

## 2. Gunicorn WSGI Server Configuration
Gunicorn serves as the interface between the web server and Python/Django:

1. Install Gunicorn:
   `pip install gunicorn`
2. Create systemd socket file `/etc/systemd/system/gunicorn.socket`:
   ```ini
   [Unit]
   Description=gunicorn socket

   [Socket]
   ListenStream=/run/gunicorn.sock

   [Install]
   WantedBy=sockets.target
   ```
3. Create systemd service file `/etc/systemd/system/gunicorn.service`:
   ```ini
   [Unit]
   Description=gunicorn daemon
   Requires=gunicorn.socket
   After=network.target

   [Service]
   User=sammy
   Group=www-data
   WorkingDirectory=/home/sammy/smart_library
   ExecStart=/home/sammy/smart_library/venv/bin/gunicorn \
             --access-logfile - \
             --workers 3 \
             --bind unix:/run/gunicorn.sock \
             smart_library.wsgi:application

   [Install]
   WantedBy=multi-user.target
   ```
4. Start services:
   ```bash
   sudo systemctl start gunicorn.socket
   sudo systemctl enable gunicorn.socket
   ```

---

## 3. Nginx Web Server Configuration
Configure Nginx as a reverse proxy to handle requests and serve static/media files directly.

Create config file `/etc/nginx/sites-available/smart_library`:
```nginx
server {
    listen 80;
    server_name yourdomain.com server_ip;

    location = /favicon.ico { access_log off; log_not_found off; }
    
    # Static Files Directory
    location /static/ {
        root /home/sammy/smart_library;
    }

    # Media Uploads Directory
    location /media/ {
        root /home/sammy/smart_library;
    }

    # Proxy to Gunicorn socket
    location / {
        include proxy_params;
        proxy_pass http://unix:/run/gunicorn.sock;
    }
}
```

Enable site configuration:
```bash
sudo ln -s /etc/nginx/sites-available/smart_library /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## 4. Firewall & SSL Setup
Enable standard HTTP and HTTPS connections, and secure the domain using Let's Encrypt:

```bash
sudo ufw allow 'Nginx Full'
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```
Follow the screen prompts to set up automatic redirects to HTTPS.
