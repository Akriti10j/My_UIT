# Use Case Diagram

The following Mermaid diagram shows the system use cases for both the **Admin** and **Student** actors.

```mermaid
graph TD
    subgraph System Boundary: Smart Library Management System
        UC1(Register on portal)
        UC2(Secure Login / Logout)
        UC3(Update Profile)
        UC4(Search Catalog & Filter)
        UC5(Request Book Issue)
        UC6(Reserve Out-of-Stock Books)
        UC7(View Borrowing History & Due Dates)
        UC8(Download PDF Issue Receipt)
        UC9(Receive Notifications & Due Reminders)

        UC10(Manage Books & Catalog CRUD)
        UC11(Approve Registrations)
        UC12(Approve Issue Requests)
        UC13(Process Returns & Log Fines)
        UC14(Generate collection PDF & Excel Reports)
        UC15(View System Audits & Logs)
        UC16(Update System Settings)
    end

    Student([Student]) --> UC1
    Student --> UC2
    Student --> UC3
    Student --> UC4
    Student --> UC5
    Student --> UC6
    Student --> UC7
    Student --> UC8
    Student --> UC9

    Admin([Administrator]) --> UC2
    Admin --> UC10
    Admin --> UC11
    Admin --> UC12
    Admin --> UC13
    Admin --> UC14
    Admin --> UC15
    Admin --> UC16

    UC5 -.-> |Requires Approval| UC12
    UC13 -.-> |Auto calculates| UC7
```
