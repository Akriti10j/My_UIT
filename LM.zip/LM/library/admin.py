from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Student, Category, Author, Book, IssueBook, Fine, BookReservation, ActivityLog

class StudentAdmin(UserAdmin):
    model = Student
    list_display = ['username', 'email', 'roll_number', 'course', 'branch', 'semester', 'is_approved']
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('roll_number', 'phone', 'course', 'branch', 'semester', 'profile_picture', 'is_approved')}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        (None, {'fields': ('email', 'first_name', 'last_name', 'roll_number', 'phone', 'course', 'branch', 'semester', 'profile_picture', 'is_approved')}),
    )

class BookAdmin(admin.ModelAdmin):
    list_display = ['title', 'isbn', 'category', 'author', 'quantity', 'available_quantity']
    search_fields = ['title', 'isbn']
    readonly_fields = ['available_quantity', 'qr_code']

class IssueBookAdmin(admin.ModelAdmin):
    list_display = ['student', 'book', 'issue_date', 'due_date', 'return_date', 'status', 'fine_amount']
    list_filter = ['status']
    search_fields = ['student__username', 'book__title']

class FineAdmin(admin.ModelAdmin):
    list_display = ['student', 'issue_record', 'amount', 'paid_status']
    list_filter = ['paid_status']

class BookReservationAdmin(admin.ModelAdmin):
    list_display = ['student', 'book', 'reservation_date', 'status']

class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'action', 'timestamp']
    readonly_fields = ['timestamp']

admin.site.register(Student, StudentAdmin)
admin.site.register(Category)
admin.site.register(Author)
admin.site.register(Book, BookAdmin)
admin.site.register(IssueBook, IssueBookAdmin)
admin.site.register(Fine, FineAdmin)
admin.site.register(BookReservation, BookReservationAdmin)
admin.site.register(ActivityLog, ActivityLogAdmin)
