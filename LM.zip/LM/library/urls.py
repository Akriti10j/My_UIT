from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# DRF Router configuration
router = DefaultRouter()
router.register(r'api/books', views.BookViewSet, basename='api-books')
router.register(r'api/students', views.StudentViewSet, basename='api-students')
router.register(r'api/issues', views.IssueBookViewSet, basename='api-issues')
router.register(r'api/fines', views.FineViewSet, basename='api-fines')

urlpatterns = [
    # Public Pages
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    
    # Dashboard Redirect Router
    path('dashboard/', views.dashboard_redirect, name='dashboard'),
    
    # Admin Pages
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/books/', views.admin_books, name='admin_books'),
    path('admin-dashboard/books/update/<int:pk>/', views.update_book, name='update_book'),
    path('admin-dashboard/books/delete/<int:pk>/', views.delete_book, name='delete_book'),
    
    path('admin-dashboard/categories/', views.admin_categories, name='admin_categories'),
    path('admin-dashboard/categories/delete/<int:pk>/', views.delete_category, name='delete_category'),
    
    path('admin-dashboard/authors/', views.admin_authors, name='admin_authors'),
    path('admin-dashboard/authors/delete/<int:pk>/', views.delete_author, name='delete_author'),
    
    path('admin-dashboard/students/', views.admin_students, name='admin_students'),
    path('admin-dashboard/students/approve/<int:pk>/', views.approve_student, name='approve_student'),
    
    path('admin-dashboard/issues/', views.admin_issues, name='admin_issues'),
    path('admin-dashboard/issues/approve/<int:pk>/', views.approve_issue_request, name='approve_issue_request'),
    path('admin-dashboard/issues/reject/<int:pk>/', views.reject_issue_request, name='reject_issue_request'),
    path('admin-dashboard/issues/return/<int:pk>/', views.return_book_view, name='return_book'),
    
    path('admin-dashboard/fines/', views.admin_fines, name='admin_fines'),
    path('admin-dashboard/fines/collect/<int:pk>/', views.collect_fine, name='collect_fine'),
    
    path('admin-dashboard/reports/', views.admin_reports, name='admin_reports'),
    path('admin-dashboard/reports/export/<str:report_type>/<str:file_format>/', views.export_report, name='export_report'),
    
    path('admin-dashboard/settings/', views.admin_settings, name='admin_settings'),
    
    # Student Pages
    path('student-dashboard/', views.student_dashboard, name='student_dashboard'),
    path('student-dashboard/profile/', views.student_profile, name='student_profile'),
    path('student-dashboard/books/search/', views.student_books_search, name='student_books_search'),
    path('student-dashboard/books/available/', views.student_books_available, name='student_books_available'),
    path('student-dashboard/books/request/<int:pk>/', views.student_request_issue, name='student_request_issue'),
    path('student-dashboard/books/reserve/<int:pk>/', views.student_reserve_book, name='student_reserve_book'),
    path('student-dashboard/history/', views.student_issued_history, name='student_issued_history'),
    path('student-dashboard/fines/', views.student_fine_details, name='student_fine_details'),
    path('student-dashboard/receipt/download/<int:pk>/', views.student_download_receipt, name='student_download_receipt'),
    path('student-dashboard/notifications/', views.student_notifications, name='student_notifications'),
    
    # REST API Auth endpoints
    path('api/login/', views.LoginAPIView.as_view(), name='api-login'),
    path('api/register/', views.RegisterAPIView.as_view(), name='api-register'),
    
    # Router endpoints
    path('', include(router.urls)),
]
