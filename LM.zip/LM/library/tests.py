import datetime
from django.test import TestCase
from django.utils import timezone
from django.contrib.auth import get_user_model
from .models import Book, Category, Author, IssueBook, Fine

Student = get_user_model()

class LibraryBusinessRulesTestCase(TestCase):
    def setUp(self):
        # Create Category & Author
        self.category = Category.objects.create(category_name="Engineering", description="Tech Books")
        self.author = Author.objects.create(author_name="Robert Martin", biography="Software pioneer")
        
        # Create Book
        self.book = Book.objects.create(
            title="Clean Code",
            isbn="978-0132350884",
            category=self.category,
            author=self.author,
            publisher="Prentice Hall",
            publication_year=2008,
            quantity=5
        )
        
        # Create Student
        self.student = Student.objects.create_user(
            username="student1",
            email="student@campus.edu",
            password="password123",
            first_name="Aman",
            last_name="Mishra",
            roll_number="CS2026",
            is_approved=True
        )

    def test_book_initialization_availability(self):
        """Verify that a book's available quantity equals its total quantity on creation."""
        self.assertEqual(self.book.available_quantity, 5)

    def test_issue_decreases_stock(self):
        """Verify that approving a book issue decreases its available quantity."""
        record = IssueBook.objects.create(student=self.student, book=self.book, status='PENDING')
        
        # Simulate admin approval
        record.status = 'ISSUED'
        record.issue_date = timezone.now().date()
        record.due_date = timezone.now().date() + datetime.timedelta(days=15)
        record.save()
        
        self.book.available_quantity -= 1
        self.book.save()
        
        self.assertEqual(self.book.available_quantity, 4)

    def test_return_increases_stock(self):
        """Verify that returning a book restores the available quantity."""
        record = IssueBook.objects.create(
            student=self.student,
            book=self.book,
            status='ISSUED',
            issue_date=timezone.now().date(),
            due_date=timezone.now().date() + datetime.timedelta(days=15)
        )
        self.book.available_quantity -= 1
        self.book.save()
        
        # Simulate Return
        record.status = 'RETURNED'
        record.return_date = timezone.now().date()
        record.save()
        
        self.book.available_quantity += 1
        self.book.save()
        
        self.assertEqual(self.book.available_quantity, 5)

    def test_fine_calculation_overdue(self):
        """Verify that dynamic overdue fine charges (₹5 per day) are calculated correctly."""
        issue_date = timezone.now().date() - datetime.timedelta(days=20)
        due_date = issue_date + datetime.timedelta(days=15) # Due date was 5 days ago
        return_date = timezone.now().date() # Returned today (5 days overdue)
        
        record = IssueBook.objects.create(
            student=self.student,
            book=self.book,
            status='ISSUED',
            issue_date=issue_date,
            due_date=due_date
        )
        
        # Process return with late charge
        record.status = 'RETURNED'
        record.return_date = return_date
        
        if record.return_date > record.due_date:
            days_late = (record.return_date - record.due_date).days
            record.fine_amount = days_late * 5 # 5 days * 5 = ₹25
            Fine.objects.create(student=self.student, issue_record=record, amount=record.fine_amount)
            
        record.save()
        
        self.assertEqual(record.fine_amount, 25)
        
        fine_record = Fine.objects.get(issue_record=record)
        self.assertEqual(fine_record.amount, 25)
        self.assertFalse(fine_record.paid_status)
