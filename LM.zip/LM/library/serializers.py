from rest_framework import serializers
from .models import Student, Book, Category, Author, IssueBook, Fine, BookReservation, ActivityLog

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name',
            'roll_number', 'phone', 'course', 'branch', 'semester',
            'profile_picture', 'is_approved', 'created_at'
        ]
        read_only_fields = ['id', 'is_approved', 'created_at']

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'category_name', 'description']

class AuthorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Author
        fields = ['id', 'author_name', 'biography']

class BookSerializer(serializers.ModelSerializer):
    category_name = serializers.ReadOnlyField(source='category.category_name')
    author_name = serializers.ReadOnlyField(source='author.author_name')

    class Meta:
        model = Book
        fields = [
            'id', 'title', 'isbn', 'category', 'category_name', 'author', 'author_name',
            'publisher', 'publication_year', 'quantity', 'available_quantity',
            'cover_image', 'qr_code', 'description', 'created_at'
        ]
        read_only_fields = ['id', 'available_quantity', 'qr_code', 'created_at']

class IssueBookSerializer(serializers.ModelSerializer):
    student_name = serializers.ReadOnlyField(source='student.username')
    book_title = serializers.ReadOnlyField(source='book.title')

    class Meta:
        model = IssueBook
        fields = [
            'id', 'student', 'student_name', 'book', 'book_title',
            'issue_date', 'due_date', 'return_date', 'status', 'fine_amount'
        ]
        read_only_fields = ['id', 'issue_date', 'return_date', 'status', 'fine_amount']

class FineSerializer(serializers.ModelSerializer):
    student_name = serializers.ReadOnlyField(source='student.username')
    book_title = serializers.ReadOnlyField(source='issue_record.book.title')

    class Meta:
        model = Fine
        fields = ['id', 'student', 'student_name', 'issue_record', 'book_title', 'amount', 'paid_status']
        read_only_fields = ['id', 'amount']

class BookReservationSerializer(serializers.ModelSerializer):
    student_name = serializers.ReadOnlyField(source='student.username')
    book_title = serializers.ReadOnlyField(source='book.title')

    class Meta:
        model = BookReservation
        fields = ['id', 'student', 'student_name', 'book', 'book_title', 'reservation_date', 'status']
        read_only_fields = ['id', 'reservation_date', 'status']

class ActivityLogSerializer(serializers.ModelSerializer):
    user_name = serializers.ReadOnlyField(source='user.username')

    class Meta:
        model = ActivityLog
        fields = ['id', 'user', 'user_name', 'action', 'details', 'timestamp']
        read_only_fields = ['id', 'timestamp']
