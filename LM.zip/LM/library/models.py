import io
import qrcode
from PIL import Image
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.files.base import ContentFile

class Student(AbstractUser):
    roll_number = models.CharField(max_length=50, unique=True, null=True, blank=True)
    phone = models.CharField(max_length=15, blank=True)
    course = models.CharField(max_length=100, blank=True)
    branch = models.CharField(max_length=100, blank=True)
    semester = models.CharField(max_length=20, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.roll_number})" if self.roll_number else self.username

class Category(models.Model):
    category_name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)

    class Meta:
        verbose_name_plural = "Categories"

    def __str__(self):
        return self.category_name

class Author(models.Model):
    author_name = models.CharField(max_length=150)
    biography = models.TextField(blank=True)

    def __str__(self):
        return self.author_name

class Book(models.Model):
    title = models.CharField(max_length=200)
    isbn = models.CharField(max_length=20, unique=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='books')
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='books')
    publisher = models.CharField(max_length=150)
    publication_year = models.IntegerField()
    quantity = models.IntegerField(default=0)
    available_quantity = models.IntegerField(default=0)
    cover_image = models.ImageField(upload_to='covers/', blank=True, null=True)
    qr_code = models.ImageField(upload_to='qrcodes/', blank=True, null=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        if is_new:
            self.available_quantity = self.quantity
            
        # Generate QR Code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"ISBN: {self.isbn}\nTitle: {self.title}\nAuthor: {self.author.author_name}\nCategory: {self.category.category_name}")
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        filename = f"qr_{self.isbn}.png"
        self.qr_code.save(filename, ContentFile(buffer.getvalue()), save=False)

        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

class IssueBook(models.Model):
    STATUS_CHOICES = (
        ('PENDING', 'Pending Approval'),
        ('ISSUED', 'Issued'),
        ('RETURNED', 'Returned'),
        ('REJECTED', 'Rejected'),
    )
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='issues')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='issues')
    issue_date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    return_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    fine_amount = models.DecimalField(max_digits=8, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.student.username} - {self.book.title} ({self.status})"

class Fine(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='fines')
    issue_record = models.ForeignKey(IssueBook, on_delete=models.CASCADE, related_name='fines_associated')
    amount = models.DecimalField(max_digits=8, decimal_places=2, default=0.00)
    paid_status = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.student.username} - ₹{self.amount} (Paid: {self.paid_status})"

class BookReservation(models.Model):
    STATUS_CHOICES = (
        ('PENDING', 'Pending'),
        ('COMPLETED', 'Completed'),
        ('EXPIRED', 'Expired'),
    )
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='reservations')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='reservations')
    reservation_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')

    def __str__(self):
        return f"{self.student.username} reserved {self.book.title}"

class ActivityLog(models.Model):
    user = models.ForeignKey(Student, on_delete=models.SET_NULL, null=True, blank=True, related_name='activity_logs')
    action = models.CharField(max_length=100)
    details = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username if self.user else 'System'} - {self.action} @ {self.timestamp.strftime('%Y-%m-%d %H:%M')}"
