import datetime
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.utils import timezone
from django.db import transaction
from django.db.models import Count, Sum, Q
from django.http import Http404, HttpResponse

# REST API imports
from rest_framework import viewsets, status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import action

from .models import Student, Book, Category, Author, IssueBook, Fine, BookReservation, ActivityLog
from .forms import StudentRegistrationForm, StudentProfileForm, BookForm, CategoryForm, AuthorForm, IssueBookForm
from .serializers import StudentSerializer, BookSerializer, CategorySerializer, AuthorSerializer, IssueBookSerializer, FineSerializer
from .utils import generate_pdf_report, generate_excel_report, send_approval_notification, send_due_date_reminder

# --- Helper Functions ---
def is_admin(user):
    return user.is_authenticated and user.is_staff

def log_activity(user, action, details):
    ActivityLog.objects.create(user=user if user.is_authenticated else None, action=action, details=details)

def get_due_date():
    return timezone.now().date() + datetime.timedelta(days=15)

def calculate_fine_for_record(record):
    """Calculates active fine dynamically if book is overdue."""
    if record.status == 'ISSUED':
        today = timezone.now().date()
        if today > record.due_date:
            days_overdue = (today - record.due_date).days
            return days_overdue * 5
    return 0

# --- Public Views ---
def home(request):
    total_books = Book.objects.aggregate(Sum('quantity'))['quantity__sum'] or 0
    total_students = Student.objects.filter(is_staff=False, is_approved=True).count()
    context = {
        'total_books': total_books,
        'total_students': total_students,
    }
    return render(request, 'public/home.html', context)

def about(request):
    return render(request, 'public/about.html')

def contact(request):
    return render(request, 'public/contact.html')

def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_approved = False # Require admin approval
            user.is_active = True
            user.save()
            log_activity(user, 'REGISTRATION', f"Student {user.username} registered. Pending approval.")
            messages.success(request, "Registration successful! Your account is pending administrator approval.")
            return redirect('login')
    else:
        form = StudentRegistrationForm()
    return render(request, 'public/register.html', {'form': form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        u = request.POST.get('username')
        p = request.POST.get('password')
        user = authenticate(username=u, password=p)
        if user is not None:
            if user.is_staff or user.is_approved:
                login(request, user)
                log_activity(user, 'LOGIN', f"User {user.username} logged in successfully.")
                return redirect('dashboard')
            else:
                messages.warning(request, "Your account is pending administrator approval.")
        else:
            messages.error(request, "Invalid username or password.")
    return render(request, 'public/login.html')

def logout_view(request):
    if request.user.is_authenticated:
        log_activity(request.user, 'LOGOUT', f"User {request.user.username} logged out.")
        logout(request)
    return redirect('home')

# --- Unified Dashboard Router ---
@login_required
def dashboard_redirect(request):
    if request.user.is_staff:
        return redirect('admin_dashboard')
    return redirect('student_dashboard')

# --- Admin Dashboard & Views ---
@user_passes_test(is_admin)
def admin_dashboard(request):
    total_books = Book.objects.aggregate(Sum('quantity'))['quantity__sum'] or 0
    total_students = Student.objects.filter(is_staff=False).count()
    
    # Calculate available books summing up available_quantity
    total_available_books = Book.objects.aggregate(Sum('available_quantity'))['available_quantity__sum'] or 0
    
    total_issued_books = IssueBook.objects.filter(status='ISSUED').count()
    total_returned_books = IssueBook.objects.filter(status='RETURNED').count()
    pending_returns = IssueBook.objects.filter(status='ISSUED', due_date__lt=timezone.now().date()).count()
    
    # Total fine collected (sum of paid fines)
    total_fine_collected = Fine.objects.filter(paid_status=True).aggregate(Sum('amount'))['amount__sum'] or 0.00
    
    # Recent requests & activity logs
    pending_approvals = Student.objects.filter(is_approved=False, is_staff=False).order_by('-created_at')[:5]
    pending_issue_requests = IssueBook.objects.filter(status='PENDING').order_by('-id')[:5]
    recent_activities = ActivityLog.objects.all().order_by('-timestamp')[:8]

    context = {
        'total_books': total_books,
        'total_students': total_students,
        'total_available_books': total_available_books,
        'total_issued_books': total_issued_books,
        'total_returned_books': total_returned_books,
        'pending_returns': pending_returns,
        'total_fine_collected': total_fine_collected,
        'pending_approvals': pending_approvals,
        'pending_issue_requests': pending_issue_requests,
        'recent_activities': recent_activities,
    }
    return render(request, 'admin_dashboard/dashboard.html', context)

# Book CRUD
@user_passes_test(is_admin)
def admin_books(request):
    books = Book.objects.all().order_by('-created_at')
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            book = form.save()
            log_activity(request.user, 'BOOK_ADD', f"Added book: {book.title} (ISBN: {book.isbn})")
            messages.success(request, f"Book '{book.title}' added successfully!")
            return redirect('admin_books')
    else:
        form = BookForm()
    return render(request, 'admin_dashboard/book_list.html', {'books': books, 'form': form})

@user_passes_test(is_admin)
def update_book(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            # Adjust available quantity dynamically based on stock changes
            diff = form.cleaned_data['quantity'] - book.quantity
            book = form.save(commit=False)
            book.available_quantity += diff
            book.save()
            log_activity(request.user, 'BOOK_UPDATE', f"Updated book: {book.title}")
            messages.success(request, f"Book '{book.title}' updated successfully!")
            return redirect('admin_books')
    else:
        form = BookForm(instance=book)
    return render(request, 'admin_dashboard/book_form.html', {'form': form, 'book': book})

@user_passes_test(is_admin)
def delete_book(request, pk):
    book = get_object_or_404(Book, pk=pk)
    title = book.title
    book.delete()
    log_activity(request.user, 'BOOK_DELETE', f"Deleted book: {title}")
    messages.success(request, f"Book '{title}' deleted successfully!")
    return redirect('admin_books')

# Category Management
@user_passes_test(is_admin)
def admin_categories(request):
    categories = Category.objects.all().order_by('category_name')
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            category = form.save()
            log_activity(request.user, 'CATEGORY_ADD', f"Added category: {category.category_name}")
            messages.success(request, f"Category '{category.category_name}' added successfully!")
            return redirect('admin_categories')
    else:
        form = CategoryForm()
    return render(request, 'admin_dashboard/category_list.html', {'categories': categories, 'form': form})

@user_passes_test(is_admin)
def delete_category(request, pk):
    category = get_object_or_404(Category, pk=pk)
    name = category.category_name
    category.delete()
    log_activity(request.user, 'CATEGORY_DELETE', f"Deleted category: {name}")
    messages.success(request, f"Category '{name}' deleted successfully!")
    return redirect('admin_categories')

# Author Management
@user_passes_test(is_admin)
def admin_authors(request):
    authors = Author.objects.all().order_by('author_name')
    if request.method == 'POST':
        form = AuthorForm(request.POST)
        if form.is_valid():
            author = form.save()
            log_activity(request.user, 'AUTHOR_ADD', f"Added author: {author.author_name}")
            messages.success(request, f"Author '{author.author_name}' added successfully!")
            return redirect('admin_authors')
    else:
        form = AuthorForm()
    return render(request, 'admin_dashboard/author_list.html', {'authors': authors, 'form': form})

@user_passes_test(is_admin)
def delete_author(request, pk):
    author = get_object_or_404(Author, pk=pk)
    name = author.author_name
    author.delete()
    log_activity(request.user, 'AUTHOR_DELETE', f"Deleted author: {name}")
    messages.success(request, f"Author '{name}' deleted successfully!")
    return redirect('admin_authors')

# Student Management & Approval
@user_passes_test(is_admin)
def admin_students(request):
    students = Student.objects.filter(is_staff=False).order_by('-created_at')
    return render(request, 'admin_dashboard/student_list.html', {'students': students})

@user_passes_test(is_admin)
def approve_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    student.is_approved = True
    student.save()
    log_activity(request.user, 'STUDENT_APPROVE', f"Approved registration for: {student.username}")
    send_approval_notification(student)
    messages.success(request, f"Student {student.username} approved successfully! Notification sent.")
    return redirect('admin_dashboard')

# Issuing & Returns
@user_passes_test(is_admin)
def admin_issues(request):
    issues = IssueBook.objects.all().order_by('-id')
    if request.method == 'POST':
        form = IssueBookForm(request.POST)
        if form.is_valid():
            # Check business limits (max 3 copies check)
            student = form.cleaned_data['student']
            book = form.cleaned_data['book']
            active_count = IssueBook.objects.filter(student=student, status='ISSUED').count()
            if active_count >= 3:
                messages.error(request, f"Student {student.username} already has 3 books issued.")
            elif book.available_quantity <= 0:
                messages.error(request, f"Book '{book.title}' is currently out of stock.")
            else:
                with transaction.atomic():
                    record = form.save(commit=False)
                    record.status = 'ISSUED'
                    record.issue_date = timezone.now().date()
                    # due_date is supplied by form widget or set defaults
                    if not record.due_date:
                        record.due_date = get_due_date()
                    record.save()
                    book.available_quantity -= 1
                    book.save()
                    log_activity(request.user, 'BOOK_ISSUE_MANUAL', f"Issued '{book.title}' to {student.username}")
                    messages.success(request, f"Book issued successfully to {student.username}.")
                return redirect('admin_issues')
    else:
        form = IssueBookForm()
    return render(request, 'admin_dashboard/issue_list.html', {'issues': issues, 'form': form})

@user_passes_test(is_admin)
def approve_issue_request(request, pk):
    record = get_object_or_404(IssueBook, pk=pk)
    book = record.book
    student = record.student
    active_count = IssueBook.objects.filter(student=student, status='ISSUED').count()
    
    if active_count >= 3:
        messages.error(request, f"Student {student.username} has reached the borrow limit of 3 books.")
        record.status = 'REJECTED'
        record.save()
    elif book.available_quantity <= 0:
        messages.error(request, f"Book '{book.title}' is out of stock.")
        record.status = 'REJECTED'
        record.save()
    else:
        with transaction.atomic():
            record.status = 'ISSUED'
            record.issue_date = timezone.now().date()
            record.due_date = get_due_date()
            record.save()
            book.available_quantity -= 1
            book.save()
            
            # If student had a pending reservation, mark it as completed
            BookReservation.objects.filter(student=student, book=book, status='PENDING').update(status='COMPLETED')
            
            log_activity(request.user, 'BOOK_ISSUE_APPROVE', f"Approved issue of '{book.title}' to {student.username}")
            messages.success(request, f"Issue request approved for {student.username}!")
    return redirect('admin_dashboard')

@user_passes_test(is_admin)
def reject_issue_request(request, pk):
    record = get_object_or_404(IssueBook, pk=pk)
    record.status = 'REJECTED'
    record.save()
    log_activity(request.user, 'BOOK_ISSUE_REJECT', f"Rejected issue of '{record.book.title}' to {record.student.username}")
    messages.success(request, "Issue request rejected.")
    return redirect('admin_dashboard')

@user_passes_test(is_admin)
def return_book_view(request, pk):
    record = get_object_or_404(IssueBook, pk=pk)
    if record.status != 'ISSUED':
        messages.error(request, "Book is not in ISSUED state.")
        return redirect('admin_issues')
        
    with transaction.atomic():
        book = record.book
        record.status = 'RETURNED'
        record.return_date = timezone.now().date()
        
        # Calculate Overdue Fine
        fine_collected = 0
        if record.return_date > record.due_date:
            days_late = (record.return_date - record.due_date).days
            fine_collected = days_late * 5 # ₹5 per day
            record.fine_amount = fine_collected
            
            # Log Fine
            Fine.objects.create(
                student=record.student,
                issue_record=record,
                amount=fine_collected,
                paid_status=False
            )
            
        record.save()
        book.available_quantity += 1
        book.save()
        
        log_activity(request.user, 'BOOK_RETURN', f"Returned '{book.title}' from {record.student.username}. Fine calculated: ₹{fine_collected}")
        messages.success(request, f"Book returned successfully. Fine charged: ₹{fine_collected}")
    return redirect('admin_issues')

# Fine Management
@user_passes_test(is_admin)
def admin_fines(request):
    fines = Fine.objects.all().order_by('-id')
    return render(request, 'admin_dashboard/fine_list.html', {'fines': fines})

@user_passes_test(is_admin)
def collect_fine(request, pk):
    fine = get_object_or_404(Fine, pk=pk)
    fine.paid_status = True
    fine.save()
    log_activity(request.user, 'FINE_COLLECT', f"Collected fine of ₹{fine.amount} from {fine.student.username}")
    messages.success(request, f"Collected fine of ₹{fine.amount} successfully.")
    return redirect('admin_fines')

# System Reports View
@user_passes_test(is_admin)
def admin_reports(request):
    return render(request, 'admin_dashboard/reports.html')

@user_passes_test(is_admin)
def export_report(request, report_type, file_format):
    """Exports PDF/Excel system summaries dynamically."""
    if report_type == 'books':
        title = "Books Catalog Inventory Report"
        headers = ["Book Title", "ISBN", "Category", "Author", "Publisher", "Total Stock", "Available"]
        books_data = Book.objects.all()
        data = [[b.title, b.isbn, b.category.category_name, b.author.author_name, b.publisher, b.quantity, b.available_quantity] for b in books_data]
        filename = f"Books_Report_{timezone.now().strftime('%Y%m%d')}"
    elif report_type == 'students':
        title = "Registered Students List"
        headers = ["Username", "Email", "Roll Number", "Course", "Branch", "Semester", "Approved Status"]
        students_data = Student.objects.filter(is_staff=False)
        data = [[s.username, s.email, s.roll_number, s.course, s.branch, s.semester, "Yes" if s.is_approved else "No"] for s in students_data]
        filename = f"Students_Report_{timezone.now().strftime('%Y%m%d')}"
    elif report_type == 'issues':
        title = "Issued Books Summary"
        headers = ["Student Name", "Book Title", "Issue Date", "Due Date", "Status"]
        issues_data = IssueBook.objects.filter(status='ISSUED')
        data = [[i.student.username, i.book.title, str(i.issue_date), str(i.due_date), i.status] for i in issues_data]
        filename = f"Issues_Report_{timezone.now().strftime('%Y%m%d')}"
    elif report_type == 'returns':
        title = "Returned Books History"
        headers = ["Student Name", "Book Title", "Issue Date", "Return Date", "Fine Charged"]
        returns_data = IssueBook.objects.filter(status='RETURNED')
        data = [[r.student.username, r.book.title, str(r.issue_date), str(r.return_date), f"Rs. {r.fine_amount}"] for r in returns_data]
        filename = f"Returns_Report_{timezone.now().strftime('%Y%m%d')}"
    elif report_type == 'fines':
        title = "Fine Collections Log"
        headers = ["Student Name", "Book Title", "Fine Amount", "Paid Status"]
        fines_data = Fine.objects.all()
        data = [[f.student.username, f.issue_record.book.title, f"Rs. {f.amount}", "Paid" if f.paid_status else "Unpaid"] for f in fines_data]
        filename = f"Fines_Report_{timezone.now().strftime('%Y%m%d')}"
    else:
        raise Http404("Report not found.")

    if file_format == 'pdf':
        return generate_pdf_report(title, headers, data, f"{filename}.pdf")
    elif file_format == 'excel':
        return generate_excel_report(title, headers, data, f"{filename}.xlsx")
    else:
        raise Http404("Format not supported.")

# Settings Screen
@user_passes_test(is_admin)
def admin_settings(request):
    if request.method == 'POST':
        messages.success(request, "Settings updated successfully!")
        return redirect('admin_settings')
    return render(request, 'admin_dashboard/settings.html')

# --- Student Dashboard & Views ---
@login_required
def student_dashboard(request):
    student = request.user
    
    # Active issues
    active_issues = IssueBook.objects.filter(student=student, status='ISSUED')
    for issue in active_issues:
        issue.calculated_fine = calculate_fine_for_record(issue)
        
    issue_history = IssueBook.objects.filter(student=student).order_by('-id')[:5]
    unpaid_fines = Fine.objects.filter(student=student, paid_status=False).aggregate(Sum('amount'))['amount__sum'] or 0.00
    
    # Book Recommendations System
    # Get categories of books this student has issued in the past
    borrowed_categories = IssueBook.objects.filter(student=student).values_list('book__category', flat=True).distinct()
    
    recommended_books = Book.objects.filter(category__in=borrowed_categories).exclude(
        id__in=IssueBook.objects.filter(student=student, status='ISSUED').values_list('book', flat=True)
    ).order_by('-created_at')[:4]
    
    # Fallback recommendations if student has not borrowed anything yet
    if not recommended_books.exists():
        # Recommend most popular books (highest issue count) or new arrivals
        recommended_books = Book.objects.annotate(num_issues=Count('issues')).order_by('-num_issues', '-created_at')[:4]

    context = {
        'active_issues': active_issues,
        'issue_history': issue_history,
        'unpaid_fines': unpaid_fines,
        'recommended_books': recommended_books,
    }
    return render(request, 'student_dashboard/dashboard.html', context)

@login_required
def student_profile(request):
    if request.method == 'POST':
        form = StudentProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            log_activity(request.user, 'PROFILE_UPDATE', "Updated personal profile details.")
            messages.success(request, "Profile updated successfully!")
            return redirect('student_profile')
    else:
        form = StudentProfileForm(instance=request.user)
    return render(request, 'student_dashboard/profile.html', {'form': form})

@login_required
def student_books_search(request):
    query = request.GET.get('q', '')
    category_id = request.GET.get('category', '')
    
    books = Book.objects.all()
    if query:
        books = books.filter(Q(title__icontains=query) | Q(isbn__icontains=query) | Q(author__author_name__icontains=query))
    if category_id:
        books = books.filter(category_id=category_id)
        
    categories = Category.objects.all()
    return render(request, 'student_dashboard/book_search.html', {'books': books, 'categories': categories, 'query': query})

@login_required
def student_books_available(request):
    books = Book.objects.filter(available_quantity__gt=0).order_by('-created_at')
    return render(request, 'student_dashboard/book_available.html', {'books': books})

@login_required
def student_request_issue(request, pk):
    book = get_object_or_404(Book, pk=pk)
    student = request.user
    
    # Business logic verification
    active_count = IssueBook.objects.filter(student=student, status='ISSUED').count()
    pending_count = IssueBook.objects.filter(student=student, status='PENDING', book=book).count()
    already_issued = IssueBook.objects.filter(student=student, status='ISSUED', book=book).count()
    
    if active_count >= 3:
        messages.error(request, "You cannot borrow more than 3 books at a time.")
    elif pending_count > 0:
        messages.warning(request, f"You already have a pending issue request for '{book.title}'.")
    elif already_issued > 0:
        messages.warning(request, f"You currently hold an active copy of '{book.title}'.")
    elif book.available_quantity <= 0:
        messages.error(request, "This book is currently out of stock.")
    else:
        IssueBook.objects.create(student=student, book=book, status='PENDING')
        log_activity(student, 'BOOK_REQUEST', f"Requested issue for book: {book.title}")
        messages.success(request, f"Issue request for '{book.title}' submitted! Pending Administrator approval.")
        
    return redirect('student_dashboard')

@login_required
def student_reserve_book(request, pk):
    book = get_object_or_404(Book, pk=pk)
    student = request.user
    
    already_reserved = BookReservation.objects.filter(student=student, book=book, status='PENDING').exists()
    
    if book.available_quantity > 0:
        messages.warning(request, f"This book is in stock. Please request an issue directly.")
    elif already_reserved:
        messages.warning(request, f"You already have a reservation for '{book.title}'.")
    else:
        BookReservation.objects.create(student=student, book=book, status='PENDING')
        log_activity(student, 'BOOK_RESERVE', f"Reserved book: {book.title}")
        messages.success(request, f"Reservation confirmed for '{book.title}'!")
        
    return redirect('student_dashboard')

@login_required
def student_issued_history(request):
    issues = IssueBook.objects.filter(student=request.user).order_by('-id')
    for issue in issues:
        issue.calculated_fine = calculate_fine_for_record(issue)
    return render(request, 'student_dashboard/my_issued_books.html', {'issues': issues})

@login_required
def student_fine_details(request):
    fines = Fine.objects.filter(student=request.user).order_by('-id')
    unpaid_fines = fines.filter(paid_status=False).aggregate(Sum('amount'))['amount__sum'] or 0.00
    return render(request, 'student_dashboard/fine_details.html', {'fines': fines, 'unpaid_fines': unpaid_fines})

@login_required
def student_download_receipt(request, pk):
    """Generates an issue receipt PDF for a student transaction."""
    issue = get_object_or_404(IssueBook, pk=pk, student=request.user)
    if issue.status != 'ISSUED':
        raise Http404("No receipt available for this status.")
        
    title = f"Smart Library - Book Issue Receipt"
    headers = ["Field", "Transaction Detail"]
    data = [
        ["Receipt ID", f"SL-TX-{issue.id}"],
        ["Student Name", f"{issue.student.first_name} {issue.student.last_name}"],
        ["Roll Number", issue.student.roll_number],
        ["Book Title", issue.book.title],
        ["ISBN", issue.book.isbn],
        ["Issue Date", str(issue.issue_date)],
        ["Due Date", str(issue.due_date)],
        ["Status", "ISSUED / ACTIVE"],
    ]
    return generate_pdf_report(title, headers, data, f"Receipt_Issue_{issue.id}.pdf")

@login_required
def student_notifications(request):
    # Fetch student's activities or upcoming dates
    active_issues = IssueBook.objects.filter(student=request.user, status='ISSUED')
    notifications = []
    
    for issue in active_issues:
        today = timezone.now().date()
        diff = (issue.due_date - today).days
        if diff <= 3 and diff >= 0:
            notifications.append(f"Reminder: Book '{issue.book.title}' is due in {diff} days ({issue.due_date}).")
        elif diff < 0:
            notifications.append(f"Overdue: Book '{issue.book.title}' was due on {issue.due_date}. Outstanding fine calculated at ₹{abs(diff)*5}.")
            
    return render(request, 'student_dashboard/notifications.html', {'notifications': notifications})


# ==========================================
# --- Django REST Framework API Viewsets ---
# ==========================================

class LoginAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_staff or user.is_approved:
                login(request, user)
                return Response({
                    "status": "success",
                    "message": "Logged in successfully.",
                    "user": StudentSerializer(user).data
                }, status=status.HTTP_200_OK)
            return Response({"status": "error", "message": "Account pending admin approval."}, status=status.HTTP_403_FORBIDDEN)
        return Response({"status": "error", "message": "Invalid credentials."}, status=status.HTTP_400_BAD_REQUEST)

class RegisterAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = StudentSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.set_password(request.data.get('password'))
            user.is_approved = False # Wait for approval
            user.save()
            return Response({
                "status": "success",
                "message": "Registration successful. Pending admin approval.",
                "user": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.IsAuthenticated()]
        return [permissions.IsAdminUser()]

class StudentViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Student.objects.filter(is_staff=False)
    serializer_class = StudentSerializer
    permission_classes = [permissions.IsAdminUser]

class IssueBookViewSet(viewsets.ModelViewSet):
    queryset = IssueBook.objects.all()
    serializer_class = IssueBookSerializer

    def get_permissions(self):
        return [permissions.IsAuthenticated()]

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return IssueBook.objects.all()
        return IssueBook.objects.filter(student=user)

    def create(self, request, *args, **kwargs):
        # Student issues a book request
        book_id = request.data.get('book')
        book = get_object_or_404(Book, id=book_id)
        student = request.user
        
        active_count = IssueBook.objects.filter(student=student, status='ISSUED').count()
        if active_count >= 3:
            return Response({"detail": "Borrow limit reached (Max 3 books)."}, status=status.HTTP_400_BAD_REQUEST)
        if book.available_quantity <= 0:
            return Response({"detail": "Book is out of stock."}, status=status.HTTP_400_BAD_REQUEST)
            
        record = IssueBook.objects.create(student=student, book=book, status='PENDING')
        serializer = self.get_serializer(record)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAdminUser])
    def approve(self, request, pk=None):
        record = self.get_object()
        book = record.book
        active_count = IssueBook.objects.filter(student=record.student, status='ISSUED').count()
        
        if active_count >= 3:
            return Response({"detail": "Student has 3 books issued already."}, status=status.HTTP_400_BAD_REQUEST)
        if book.available_quantity <= 0:
            return Response({"detail": "Book is out of stock."}, status=status.HTTP_400_BAD_REQUEST)
            
        with transaction.atomic():
            record.status = 'ISSUED'
            record.issue_date = timezone.now().date()
            record.due_date = get_due_date()
            record.save()
            
            book.available_quantity -= 1
            book.save()
            
        return Response(self.get_serializer(record).data)

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAdminUser])
    def return_book(self, request, pk=None):
        record = self.get_object()
        if record.status != 'ISSUED':
            return Response({"detail": "Book is not currently issued."}, status=status.HTTP_400_BAD_REQUEST)
            
        with transaction.atomic():
            book = record.book
            record.status = 'RETURNED'
            record.return_date = timezone.now().date()
            
            fine_collected = 0
            if record.return_date > record.due_date:
                days_late = (record.return_date - record.due_date).days
                fine_collected = days_late * 5
                record.fine_amount = fine_collected
                Fine.objects.create(student=record.student, issue_record=record, amount=fine_collected)
                
            record.save()
            book.available_quantity += 1
            book.save()
            
        return Response({
            "status": "success",
            "message": f"Book returned successfully. Fine charged: ₹{fine_collected}",
            "record": self.get_serializer(record).data
        })

class FineViewSet(viewsets.ModelViewSet):
    queryset = Fine.objects.all()
    serializer_class = FineSerializer

    def get_permissions(self):
        return [permissions.IsAuthenticated()]

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return Fine.objects.all()
        return Fine.objects.filter(student=user)
