// Smart Library Management System - JavaScript Controller

document.addEventListener('DOMContentLoaded', () => {
    // 1. Persistent Dark Mode Toggle
    const themeToggleBtn = document.getElementById('themeToggle');
    const themeIcon = themeToggleBtn ? themeToggleBtn.querySelector('i') : null;
    
    // Check local storage for preference
    const savedTheme = localStorage.getItem('library-theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        if (themeIcon) {
            themeIcon.className = 'bi bi-sun-fill';
        }
    } else {
        document.body.classList.remove('dark-mode');
        if (themeIcon) {
            themeIcon.className = 'bi bi-moon-fill';
        }
    }

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const isDarkMode = document.body.classList.contains('dark-mode');
            localStorage.setItem('library-theme', isDarkMode ? 'dark' : 'light');
            
            if (themeIcon) {
                themeIcon.className = isDarkMode ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
            }
        });
    }

    // 2. Sidebar Toggle Trigger
    const sidebarCollapseBtn = document.getElementById('sidebarCollapse');
    const sidebar = document.getElementById('sidebar');
    if (sidebarCollapseBtn && sidebar) {
        sidebarCollapseBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }

    // 3. Auto Dismiss Alerts
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                bsAlert.close();
            }
        }, 5000); // 5 seconds
    });
});
