from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import Student, Book, Category, Author, IssueBook, BookReservation

class BootstrapFormMixin:
    """Mixin to automatically apply Bootstrap 5 form classes to all fields."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs['class'] = 'form-check-input'
            elif isinstance(field.widget, forms.FileInput):
                field.widget.attrs['class'] = 'form-control'
            else:
                field.widget.attrs['class'] = 'form-control'

class StudentRegistrationForm(BootstrapFormMixin, UserCreationForm):
    first_name = forms.CharField(max_length=150, required=True, help_text="Required.")
    last_name = forms.CharField(max_length=150, required=True, help_text="Required.")
    email = forms.EmailField(required=True, help_text="Required.")

    class Meta(UserCreationForm.Meta):
        model = Student
        fields = UserCreationForm.Meta.fields + (
            'email',
            'first_name',
            'last_name',
            'roll_number',
            'phone',
            'course',
            'branch',
            'semester',
            'profile_picture',
        )

class StudentProfileForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'course',
            'branch',
            'semester',
            'profile_picture'
        ]

class BookForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Book
        fields = [
            'title',
            'isbn',
            'category',
            'author',
            'publisher',
            'publication_year',
            'quantity',
            'cover_image',
            'description'
        ]

class CategoryForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Category
        fields = ['category_name', 'description']

class AuthorForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Author
        fields = ['author_name', 'biography']

class IssueBookForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = IssueBook
        fields = ['student', 'book', 'due_date']
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'}),
        }
